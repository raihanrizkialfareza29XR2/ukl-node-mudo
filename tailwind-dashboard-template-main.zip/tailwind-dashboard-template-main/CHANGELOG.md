# CHANGELOG.md

## [1.3.1] - 2022-01-27

- Fix tailwind.config.js file

## [1.3.0] - 2022-01-25

- Replace CRA (Create React App) with Vite
- Remove Craco
- Update dependencies

## [1.2.0] - 2021-12-13

- Update Tailwind 3
- Several improvements

## [1.1.1] - 2021-11-23

- Alignment issue## [1.1.1] - 2021-11-23

- Alignment issue

## [1.1.0] - 2021-11-15

- Update dependencies
- Enable Tailwind JIT
- Add expandable / collapsible sidebar feature

## [1.0.0] - 2021-04-20

First release