import React from 'react'

const NoPermission = () => {
  return (
    <div>
        Tidak ada akses khusus
    </div>
  )
}

export default NoPermission